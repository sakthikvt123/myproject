from django.urls import path
from .views import login_view, posts_view, comments_view

urlpatterns = [
    path('login/', login_view, name='login'),
    path('posts/', posts_view, name='posts'),
    path('posts/<int:post_id>/comments/', comments_view, name='comments'),
]
