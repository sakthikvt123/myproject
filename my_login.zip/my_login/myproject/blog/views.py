import requests
from django.shortcuts import render
from django.contrib.auth.decorators import login_required

from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect
from django.contrib import messages

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('posts')
        else:
            messages.error(request, 'Invalid username or password')
    return render(request, 'blog/login.html')


@login_required
def posts_view(request):
    response = requests.get('https://jsonplaceholder.typicode.com/posts')
    posts = response.json()
    return render(request, 'blog/posts.html', {'posts': posts})

@login_required
def comments_view(request, post_id):
    response = requests.get(f'https://jsonplaceholder.typicode.com/posts/{post_id}/comments')
    comments = response.json()
    return render(request, 'blog/comments.html', {'comments': comments})

